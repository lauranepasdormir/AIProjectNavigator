import React, { Suspense, lazy } from "react";
import { Switch, Route } from "wouter";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { AuthProvider } from "@/hooks/use-auth";

// Lazy load pages
const ChatForm = lazy(() => import("@/pages/ChatForm"));
const AdminPanel = lazy(() => import("@/pages/AdminPanel"));
const LoginPage = lazy(() => import("@/pages/LoginPage"));
const NotFound = lazy(() => import("@/pages/not-found"));

function Router() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 pb-24">
      <Header />
      <main className="flex-1">
        <Suspense fallback={<div>Loading...</div>}>
          <Switch>
            <Route path="/" component={ChatForm} />
            <Route path="/app" component={ChatForm} />
            <Route path="/login" component={LoginPage} />
            <ProtectedRoute path="/admin" component={AdminPanel} />
            <Route component={NotFound} />
          </Switch>
        </Suspense>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
